import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: devuser
 * Date: 12-8-25
 * Time: 下午4:16
 * To change this template use File | Settings | File Templates.
 */
public class TestHql {
    public static void main(String[] args) {
        System.out.print(new Date().getTime());
    }
}
