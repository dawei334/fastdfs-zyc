package cn.vivame.fdfs.action;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;


import javax.servlet.ServletContext;

import org.csource.common.NameValuePair;
import org.csource.fastdfs.*;

import cn.vivame.fdfs.vo.Fdfs_file;

/**
 * 
 * @author wa
 * 
 */
public class TestAction { // 实现ServletContextAware接口，获取本地路径

//	public Fdfs_file getfile(String path, String name) {
//		System.out
//				.println("java.version=" + System.getProperty("java.version"));
//		String conf_filename = Thread.currentThread().getContextClassLoader()
//				.getResource("fdfs_client.conf").getPath();
//		String fileId = null;
//        FileInfo fi=null;
//		try {
//			ClientGlobal.init(conf_filename);
//			System.out.println("network_timeout="
//					+ ClientGlobal.g_network_timeout + "ms");
//			System.out.println("charset=" + ClientGlobal.g_charset);
//			TrackerClient tracker = new TrackerClient();
//			TrackerServer trackerServer = tracker.getConnection();
//			StorageServer storageServer = null;
//			StorageClient1 client = new StorageClient1(trackerServer,
//					storageServer);
//			NameValuePair[] metaList = new NameValuePair[1];
//			metaList[0] = new NameValuePair("fileName", path);
//			fileId = client.upload_file1(path, null, metaList);
//            fi=client.get_file_info1(fileId);
//			System.out.println("upload success. file id is: " + fileId);
//			trackerServer.close();
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
//		Fdfs_file f = new Fdfs_file();
//		String MD5 = cn.vivame.fdfs.util.DigestUtil.getMd5DigestFile(path);
//		f.setMD5(MD5);
//		f.setCreated(new Date());
//		f.setFile_id(fileId);
//       f.setFileSize(fi.getFileSize());
//		f.setType(path.substring(path.lastIndexOf(".") + 1));
//		f.setFile_name(name);
//
//		return f;
//	}

	public String copyFile(InputStream in, String fileName,
			ServletContext servletContext) throws IOException {
		String path = servletContext.getRealPath(String
				.valueOf(File.separatorChar)) + fileName;
		FileOutputStream fs = new FileOutputStream(path);
		byte[] buffer = new byte[1024 * 1024];
		int bytesum = 0;
		int byteread = 0;
		while ((byteread = in.read(buffer)) != -1) {
			bytesum += byteread;
			fs.write(buffer, 0, byteread);
			fs.flush();
		}
		fs.close();
		in.close();
		return path;
	}
}